package com.example.A_DEMO.service;

import java.util.List;
import com.example.A_DEMO.dto.EmployeeDTO;
import com.example.A_DEMO.exception.RetailException;


public interface EmployeeService {
	public EmployeeDTO getEmployee(Integer EmployeeID) throws RetailException;
	public List<EmployeeDTO> getAllEmployees() throws RetailException;
	public Integer addEmployee(EmployeeDTO employee) throws RetailException;
	public void updateEmployee(Integer EmployeeID, String EmployeeName) throws RetailException;
}
