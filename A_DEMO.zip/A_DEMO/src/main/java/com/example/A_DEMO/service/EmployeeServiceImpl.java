package com.example.A_DEMO.service;

import org.springframework.transaction.annotation.Transactional;

import com.example.A_DEMO.dto.EmployeeDTO;
import com.example.A_DEMO.entity.Employee;
import com.example.A_DEMO.exception.RetailException;
import com.example.A_DEMO.repository.EmployeeRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public EmployeeDTO getEmployee(Integer EmployeeID) throws RetailException {
		Optional<Employee> optional = employeeRepository.findById(EmployeeID);
		Employee employee = optional.orElseThrow(() -> new RetailException("Service.EMPLOYEE_NOT_FOUND"));
		EmployeeDTO employee2 = new EmployeeDTO();
		employee2.setEmployeeID(employee.getEmployeeID());
		employee2.setEmployeeName(employee.getEmployeeName());
		employee2.setDateOfBirth(employee.getDateOfBirth());
		employee2.setDateOfJoining(employee.getDateOfJoining());
		employee2.setCity(employee.getCity());
		employee2.setDepartment(employee.getDepartment());
		employee2.setManager(employee.getManager());
		employee2.setSalary(employee.getSalary());
		return employee2;
	}
	
	@Override
	public List<EmployeeDTO> getAllEmployees() throws RetailException {
		Iterable<Employee> employees = employeeRepository.findAll();
		List<EmployeeDTO> employees2 = new ArrayList<>();
		employees.forEach(employee-> {
			EmployeeDTO emp = new EmployeeDTO();
			emp.setEmployeeID(employee.getEmployeeID());
			emp.setEmployeeName(employee.getEmployeeName());
			emp.setDateOfBirth(employee.getDateOfBirth());
			emp.setDateOfJoining(employee.getDateOfJoining());
			emp.setCity(employee.getCity());
			emp.setDepartment(employee.getDepartment());
			emp.setManager(employee.getManager());
			emp.setSalary(employee.getSalary());
			employees2.add(emp);
		});
		if (employees2.isEmpty())
			throw new RetailException("Service.EMPLOYEES_NOT_FOUND");
		return employees2;
	}

	@Override
	public Integer addEmployee(EmployeeDTO employee) throws RetailException {
		Employee employeeEntity = new Employee();
		employeeEntity.setEmployeeID(employee.getEmployeeID());
		employeeEntity.setEmployeeName(employee.getEmployeeName());
		employeeEntity.setDateOfBirth(employee.getDateOfBirth());
		employeeEntity.setDateOfJoining(employee.getDateOfJoining());
		employeeEntity.setCity(employee.getCity());
		employeeEntity.setDepartment(employee.getDepartment());
		employeeEntity.setManager(employee.getManager());
		employeeEntity.setSalary(employee.getSalary());
		Employee employeeEntity2 = employeeRepository.save(employeeEntity);
		return employeeEntity2.getEmployeeID();
	}
	
	@Override
	public void updateEmployee(Integer EmployeeID, String EmployeeName) throws RetailException {
		Optional<Employee> employee = employeeRepository.findById(EmployeeID);
		Employee c = employee.orElseThrow(() -> new RetailException("Service.EMPLOYEE_NOT_FOUND"));
		c.setEmployeeName(EmployeeName);
	}
}
