package com.example.A_DEMO.api;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.A_DEMO.dto.EmployeeDTO;
import com.example.A_DEMO.exception.RetailException;
import com.example.A_DEMO.service.EmployeeService;

@RestController
@RequestMapping(value = "/retail")

public class EmployeeAPI {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private Environment environment;
	
	@GetMapping(value = "/employees")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployees() throws RetailException {
		List<EmployeeDTO> employeeList = employeeService.getAllEmployees();
		return new ResponseEntity<>(employeeList, HttpStatus.OK);
	}

	@GetMapping(value = "/employees/{EmployeeID}")
	public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable Integer EmployeeID) throws RetailException {
		EmployeeDTO employee = employeeService.getEmployee(EmployeeID);
		return new ResponseEntity<>(employee, HttpStatus.OK);
	}

	@PostMapping(value = "/employees")
	public ResponseEntity<String> addEmployee( @RequestBody EmployeeDTO employee) throws RetailException {
		Integer EmployeeID = employeeService.addEmployee(employee);
		String successMessage = environment.getProperty("API.INSERT_SUCCESS") + EmployeeID;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}
	
	@PutMapping(value = "/employees/{EmployeeID}")
	public ResponseEntity<String> updateEmployee(@PathVariable Integer EmployeeID, @RequestBody EmployeeDTO employee)
			throws RetailException {
		employeeService.updateEmployee(EmployeeID, employee.getEmployeeName());
		String successMessage = environment.getProperty("API.UPDATE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

}
