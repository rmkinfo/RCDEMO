package com.example.A_DEMO.exception;

public class RetailException extends Exception{

	private static final long serialVersionUID = 1L;

	public RetailException(String message) {
		super(message);
		
	}
}
