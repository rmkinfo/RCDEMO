package com.example.A_DEMO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ADemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ADemoApplication.class, args);
	}

}
